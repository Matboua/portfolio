export default function Experience() {
	return (
		<section>
			<h1>Experience</h1>
		</section>
	);
}
