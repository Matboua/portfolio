export default function Education() {
	return (
		<section>
			<h1>Education</h1>
		</section>
	);
}
