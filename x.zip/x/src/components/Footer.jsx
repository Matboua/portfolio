export default function Footer() {
	return (
		<section>
			<h1>Footer</h1>
		</section>
	);
}
