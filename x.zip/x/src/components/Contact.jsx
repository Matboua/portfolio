export default function Contact() {
	return (
		<section>
			<h1>Contact</h1>
		</section>
	);
}
