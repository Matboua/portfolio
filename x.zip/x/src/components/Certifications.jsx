export default function Certifications() {
	return (
		<section>
			<h1>Certifications</h1>
		</section>
	);
}
