export default function Skills() {
	return (
		<section>
			<h1>Skills</h1>
		</section>
	);
}
